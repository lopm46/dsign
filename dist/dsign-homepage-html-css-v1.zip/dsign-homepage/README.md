# D-SIGN — export HTML / CSS

Livraison du 4 novembre 2026 ; rendu contrôlé le 3 novembre. Reprise améliorée de la homepage choisie, d’après la capture https://i.imgur.com/KfDjzWy.jpeg.

## Ouvrir la page

Décompresser l’archive, conserver le dossier `assets` à côté des fichiers, puis ouvrir `index.html` dans un navigateur récent. Aucun framework, gestionnaire de paquets ou build n’est nécessaire. Toutes les images et les polices sont locales.

Pour un aperçu avec un serveur local, depuis ce dossier :

```bash
python3 -m http.server 4173
```

Ouvrir ensuite `http://localhost:4173/`. Cette méthode a été utilisée pour les contrôles de rendu et d’interaction.

## Contenu de l’export

```text
index.html                Page complète avec texte vivant
styles.css                Styles, tokens et adaptations responsive
script.js                 Fermeture du menu mobile et détails accessibles
DESIGN.md                 Charte extraite de la page livrée
VERIFICATION.md           Contrôles réalisés et limites
assets/
  logo.svg                Logo officiel original, sans modification
  fonts/                  Instrument Sans local, deux graisses et licence OFL
  images/                 Cinq ambiances, versions WebP 800 et 1600 px
  image-provenance.json    Origine et prompts des visuels
```

Les fichiers `.webp.json` conservent également le prompt de génération de chaque image. Ils n’ajoutent aucune dépendance au fonctionnement de la page.

## Ce qui est conservé

- Logo D-SIGN complet, couleurs et proportions d’origine.
- Hero bleu avec image en D, grand titre et accent vert.
- Même ordre : expertises, projets, approche, matériaux, contact et pied de page.
- Même principe de lignes image/texte pour les trois services.
- Grands visuels, alternance de surfaces blanches et bleues, liens à flèche.

## Ce qui est amélioré

- Grille, marges, densité des lignes de services et échelle typographique cohérentes.
- CTA harmonisés autour de « Parlons de votre projet ».
- Particuliers et professionnels explicitement présents dès l’introduction.
- Logo intact ; contrastes de texte, de liens et des états de survol renforcés.
- Navigation mobile native, fermeture par lien/Escape/clic extérieur et retour du focus.
- « Notre façon de travailler » déplie une explication courte, sans fenêtre modale.
- Informations de contact dépliables et coordonnées cliquables.
- Images responsives, dimensions réservées, chargement progressif et fontes locales.
- Navigation clavier, lien d’évitement, mouvement réduit et mise en page mobile.

Le code est une reconstruction de la capture, pas le HTML source du site hébergé. La famille typographique de la capture n’était pas disponible : Instrument Sans a été choisie pour conserver une expression proche.

## Images et contenu

Les cinq images sont des **visuels d’ambiance générés pour cette présentation**, inspirés des scènes de la capture. Elles ne représentent pas des réalisations livrées ni des membres de l’équipe D-SIGN. Leur nature illustrative est indiquée dans la page. Ne pas supprimer cette précision tant que les images ne sont pas remplacées par des photographies réelles attribuées.

Pour remplacer un visuel, conserver les deux tailles correspondantes ou adapter son `srcset`. Mettre à jour le texte alternatif et la provenance. Pour une étude de cas réelle, documenter le lieu, la mission et le résultat au lieu de convertir une inspiration en réalisation.

Le logo original provient de `https://dsign-gbs.fr/wp-content/uploads/2024/12/logo.svg`. SHA-256 : `cfc31d8acfed3c19cf01688f9a0f42f86cc92d1cee3a241ad232626b63683841`.

## Liens et contact

Les liens de navigation parcourent les sections de cette page. Les services, le portfolio, les matériaux et le bouton final renvoient vers les pages existantes de `dsign-gbs.fr` ; ces destinations nécessitent Internet. Les liens téléphone et e-mail ouvrent les applications correspondantes.

L’export ne contient aucun faux formulaire, calcul de devis ou confirmation d’envoi. Le bouton final rejoint le parcours existant `/devis-en-ligne/`. Aucun envoi n’a été effectué pendant la réalisation ou les contrôles.

## Préparer l’intégration WordPress

Il s’agit d’un export statique, **pas d’un thème WordPress installable**.

1. Reprendre le header et le footer dans les templates appropriés et le contenu de `<main>` dans le template d’accueil.
2. Charger `styles.css` et `script.js` via les fonctions d’enqueue de WordPress, uniquement sur la page ou le template concerné. Les styles globaux de cet export ne doivent pas être injectés sans adaptation dans un thème existant.
3. Transformer les chemins des images et polices en URLs du thème ou de la médiathèque. Garder le SVG complet, avec ses dimensions et ses couleurs.
4. Rendre éditables les textes, visuels, liens des services et projets, étapes et coordonnées à l’aide de blocs/patterns ou des champs du site.
5. Remplacer les liens absolus si les slugs changent ; préserver les destinations et redirections utiles.
6. Compléter les informations légales du site et valider les contenus métier, la zone d’intervention et les médias avant une mise en ligne.
7. Si un formulaire est ajouté, le connecter à une réception réelle avec validation serveur et états de succès/erreur ; ne pas simuler un envoi en JavaScript.

Les variables de `:root` dans `styles.css` centralisent couleurs, largeur de contenu, espacements et transitions. Les principaux seuils responsive sont 1120, 900, 760 et 360 CSS px.

La charte `DESIGN.md` documente la palette, l’échelle typographique, la grille et les composants tels qu’ils sont utilisés dans la page. Elle sert de référence pour les prochaines pages.

## Contrôles

Les contrôles réalisés et leurs limites sont consignés dans `VERIFICATION.md`. L’export ne contient ni service externe de polices, ni script de mesure, ni dépendance JavaScript tierce.
