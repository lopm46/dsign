"use strict";

(() => {
  const menu = document.getElementById("mobile-menu");
  const summary = menu?.querySelector("summary");

  const closeMenu = (returnFocus = false) => {
    if (!menu?.open) return;
    menu.open = false;
    if (returnFocus) summary?.focus();
  };

  menu?.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => closeMenu());
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && menu?.open) {
      closeMenu(true);
    }
  });

  document.addEventListener("click", (event) => {
    if (menu?.open && !menu.contains(event.target)) closeMenu();
  });

  const desktop = window.matchMedia("(min-width: 901px)");
  desktop.addEventListener("change", (event) => {
    if (event.matches) closeMenu();
  });

  const information = document.getElementById("informations");
  const openInformation = () => {
    if (window.location.hash === "#informations" && information) {
      information.open = true;
    }
  };

  document.querySelectorAll('a[href="#informations"]').forEach((link) => {
    link.addEventListener("click", () => {
      if (information) information.open = true;
    });
  });
  window.addEventListener("hashchange", openInformation);
  openInformation();
})();
