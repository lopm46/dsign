# Vérification de l’export

Version contrôlée : 3 novembre 2026. Portée : export statique HTML/CSS/JS, pas thème WordPress ni site publié.

## Contrôles réalisés

- Rendu et ressources contrôlés dans Chromium headless à **320, 390, 768, 1024, 1440 et 1920 CSS px** : aucun débordement de page, aucune image/police manquante, ancre locale morte ou erreur navigateur détectée.
- Captures desktop 1440 px et mobile 390 px prises après défilement et chargement des images différées, puis inspectées visuellement.
- Navigation mobile : ouverture, fermeture par Escape, retour du focus au bouton et fermeture après choix d’une section.
- Action du hero : arrivée sur le contact ; téléphone et e-mail exposés comme liens natifs.
- Six destinations HTTPS externes vérifiées en lecture le 3 novembre 2026 : HTTP 200, avec redirections suivies pour les pages de services. Aucun formulaire n’a été soumis.
- Dépliants méthode et informations du site : ouverture/fermeture contrôlées. Menu et méthode également testés avec JavaScript désactivé.
- États de survol : correction et contrôle de la couleur calculée du lien de contact mobile. Texte navy sur fond green-hover.
- Scan **axe-core 4.10.3**, règles WCAG A/AA applicables, à 390 et 1440 px : **aucune violation automatisée détectée** sur les vues contrôlées. Cela ne remplace pas une recette complète avec technologies d’assistance.
- Logo : SHA-256 identique à l’original fourni. Pas de filtre ni de modification des proportions.
- Provenance des images : cinq visuels illustratifs documentés ; dix dérivés WebP avec prompts conservés ; aucune image n’est présentée comme une réalisation livrée.
- Passe mécanique Impeccable effectuée. Le défaut réel de contraste mobile est corrigé ; la typographie et le padding du hero ont été conservés après vérification du rendu et de la référence.
- **Revue visuelle indépendante : disposition `ship` pour cet export statique**, sans écart matériel bloquant identifié à cette portée.
- Charte `DESIGN.md` extraite du code livré ; documentation finalisée directement après interruption du rôle de documentation. Cette reprise n’a pas modifié le rendu validé.

## Limites

- Tests en navigateur automatisé, sans appareil physique ni session complète de lecteur d’écran.
- Le navigateur cloud interdit la navigation `file://` (`ERR_BLOCKED_BY_ADMINISTRATOR`). L’ouverture directe du fichier n’a donc pas pu être validée dans cet environnement ; le dossier complet a été testé sur serveur HTTP local.
- Aucun formulaire, envoi de message ou calcul d’estimation n’a été simulé. Le parcours de demande existant reste externe.
- Aucune mesure terrain Core Web Vitals, recette WordPress, certification d’accessibilité ou mise en ligne n’est revendiquée.
- Les médias originaux de la capture n’étaient pas disponibles : les scènes ont été recréées comme ambiances illustratives. La reprise vise la structure et l’expression visuelle, pas une identité pixel à pixel.

La page est fournie avec tous ses assets locaux. Les liens sortants nécessitent Internet ; leur disponibilité future dépend du site existant.
